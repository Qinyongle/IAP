#ifndef __DELAY_H_
#define __DELAY_H_
#include "stm32f10x.h"
#ifndef __DELAY_C_
#define __DELAY_C_  extern
#else 
#define __DELAY_C_
#endif

#define SuppendSysTickInterrupt //�Ƿ�֧��ϵͳ��ʱ���ж�

__DELAY_C_ u32 SysTickCnt2;

void DelayInit(void);
void delay_us(u32 time);
void delay_ms(u32 time);
void delay_s(u32 time);

#endif
